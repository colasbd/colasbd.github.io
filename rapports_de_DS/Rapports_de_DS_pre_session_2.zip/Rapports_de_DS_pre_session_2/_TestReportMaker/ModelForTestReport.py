import numpy as np


class ResultatDS:
    
    def __init__(self, nom):
        self.nom = nom
        self.eleves = []
        self.parties = []
        self.resultats = []


class Eleve:
    
    def __init__(self, nom, prenomEleve):
        self.nom = nom
        self.prenom = prenomEleve

    def prenomEtNom(self):
        return self.prenom + " " + self.nom
        
    def stringForLatex(self):
        modele = r"**prenom** \textsc{**nom**}"
        result = modele.replace("**prenom**", self.prenom)
        result = result.replace("**nom**", self.nom)
        return result
      
      
class Question:
    
    def __init__(self, nom, coefficient, resolution):
        self.nom = nom
        self.coefficient = coefficient
        self.resolution = resolution
        self.partie = None
        self.moyenneClasse = -1
        self.ecartTypeClass = -1
        
        
class Partie:
    
    def __init__(self, nom):
        self.nom = nom
        self.questions = []
        
    def ajouteQuestion(self, question):
        self.questions.append(question)
        question.partie = self


class ResultatQuestion:

    def __init__(self, eleve, question):
        self.eleve = eleve
        self.question = question
        self.valeur = 0
        self.estTraitee = False
        
    def attribueValeur(self, valeur):
        self.valeur = valeur
        self.estTraitee = True
        
    def nombreDePoints(self):
        return self.valeur/self.question.resolution*self.question.coefficient
      
        
##

# jacques = Eleve("DUPUIS", "Jacques")
# marie = Eleve("HÉZARD", "Marie")
# 
# qu1 = Question("Q1", 2, 4)
# qu2 = Question("Q2", 2, 4)
# qu3 = Question("Q3", 1, 1)
# 
# partie = Partie("Partie 1")