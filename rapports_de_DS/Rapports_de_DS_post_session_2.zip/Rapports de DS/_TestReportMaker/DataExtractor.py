pathToTestReportMaker = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/_TestReportMaker"

import os
os.chdir(pathToTestReportMaker)

from ModelForTestReport import *
from CSVReader import *

##


# ex: listeObjets = [eleve1, eleve2, ...]
# etiquette : e -> e.bilanDS.noteBrute
def classeObjets(listeObjets, etiquette, inverse):
    result = sorted(listeObjets, key = etiquette, reverse = inverse)
    return result



class DataExtractor:
    
    def __init__(self, nameFile, nomDS):
        monCSVReader = CSVReader(";")
        result, infosForKeys = monCSVReader.processCSVFile(nameFile, 3, 0, [1, 2])
        self.result = result
        self.infosForKeys = infosForKeys
        self.resultatDS = ResultatDS(nomDS)
        
    def extraitListeEleves(self):
        for dico in self.result:
            nom = dico["NOM"]
            eleve = Eleve(nom, "")
            self.resultatDS.eleves.append(eleve)
            
    def creePartieEtQuestions(self):
        partie = Partie("Unique Partie")
        partie.uniquePartie = True
        
        for x in self.infosForKeys:
            if x != "NOM":
                nomQuestion = x
                coeff = float(self.infosForKeys[x][0].replace(",", "."))
                resolution = int(self.infosForKeys[x][1])
                question = Question(nomQuestion, coeff, resolution)
                partie.ajouteQuestion(question)
                
        self.resultatDS.parties.append(partie)
        
    def extraitResultats(self):
        for dico in self.result:
            nomEleve = dico["NOM"]
            eleve = self.resultatDS.eleveByName(nomEleve)
            for x in dico:
                if x != "NOM":
                    nomQuestion = x
                    question = self.resultatDS.questionByName(nomQuestion)
                    resultat = ResultatQuestion(eleve, question)
                    valeur = int(dico[x])
                    resultat.attribueValeur(valeur)
                    self.resultatDS.resultats.append(resultat)

    def calculeIndicateurs(self):
        # Calcul des points
        for resultat in self.resultatDS.resultats:
            eleve = resultat.eleve
            question = resultat.question
            points = resultat.nombreDePoints()
            question.statistique.ajouteDonnee(points)
            eleve.bilanDS.ajoutePoints(points)
        
        # Calcul des stats pour chaque question
        parties = self.resultatDS.parties
        for p in parties:
            for q in p.questions:
                q.statistique.calculeIndicateurs()
        
        # Classement des notes des élèves
        eleves = self.resultatDS.eleves
        def etiquette(e):
            return e.bilanDS.noteBrute
        elevesClasses = classeObjets(eleves, etiquette, True)
        
        rang = 0
        for eleve in elevesClasses:
            rang = rang + 1
            eleve.bilanDS.classement = rang
            
        # Bilan DS
        notesBrutes = []
        for eleve in eleves:
            noteBrute = eleve.bilanDS.noteBrute
            notesBrutes.append(noteBrute)
        noteMaximale = max(notesBrutes)
        
        for eleve in eleves:
            noteBrute = eleve.bilanDS.noteBrute
            noteFinale = noteBrute/noteMaximale*20
            self.resultatDS.statistiqueBrute.ajouteDonnee(noteBrute)
            self.resultatDS.statistique.ajouteDonnee(noteFinale)
            eleve.bilanDS.noteFinale = noteFinale
            
        self.resultatDS.statistique.calculeIndicateurs()
        self.resultatDS.statistiqueBrute.calculeIndicateurs()
   
                        
            
            
##

pathToCSVFile = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/DS1_exemple/tableau.csv"

monDataExtractor = DataExtractor(pathToCSVFile, "DS Test")

##

monDataExtractor.extraitListeEleves()
monDataExtractor.creePartieEtQuestions()
monDataExtractor.extraitResultats()

##

monDataExtractor.calculeIndicateurs()
