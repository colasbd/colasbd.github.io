pathToTestReportMaker = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/_TestReportMaker"

import os
os.chdir(pathToTestReportMaker)

from ModelForTestReport import *
from LatexDiagramsMaker_v2 import *


##

class LatexFileMaker:
    
    def __init__(self):
        
        readPreambule = open("preambule.tex", "r", encoding = "utf-8")
        self.preambule = readPreambule.read()
        
        readGenericFile = open("genericFile.tex", "r", encoding = "utf-8")
        self.genericFile = readGenericFile.read()
        
        self.diagramMaker = LatexDiagramDrawer()
        
        self.latexDiagramParameter = LatexDiagramParameter()
        self.latexDiagramParameter.width = "10cm"
        self.latexDiagramParameter.height = "4cm"
        self.latexDiagramParameter.withProtectionAgainstNegative = False

        
    def histogrammeNotes(self, eleve, resultatDS):
        notesClasse = resultatDS.statistique.donnees
        noteEleve = eleve.bilanDS.noteFinale
        
        self.latexDiagramParameter.numberOfBars = min(len(notesClasse),15)
        
        return self.diagramMaker.draw(notesClasse, noteEleve, self.latexDiagramParameter)

        
    def stringLatexForStudent(self, eleve, resultatDS):
        result = self.genericFile
        result = result.replace("**NOM**", eleve.nom)
        result = result.replace("**PRENOM**", "Camille")
        
        result = result.replace("**NOTE**", eleve.bilanDS.stringLatexForNoteFinale())
        
        classementEleve = eleve.bilanDS.classement
        classementMax = resultatDS.statistique.tailleEchantillon()
        result = result.replace("**CLASSEMENT**", str(classementEleve))
        result = result.replace("**CLASSEMENT-MAX**", str(classementMax))
        
        moyenneClasse = resultatDS.statistique.stringLatexForMoyenne()
        ecartTypeClasse = resultatDS.statistique.stringLatexForEcartType()
        result = result.replace("**MOYENNE-CLASSE**", moyenneClasse)
        result = result.replace("**ECARTTYPE**", ecartTypeClasse)
        
        diagramme = self.histogrammeNotes(eleve, resultatDS)
        result = result.replace("**DIAGRAMME**", diagramme)
        
        return result


    def stringLatexForDS(self, resultatDS):
        result = self.preambule + r"\begin{document}" + "\n\n"
        for eleve in resultatDS.eleves:
            stringLatexEleve = self.stringLatexForStudent(eleve, resultatDS)
            result = result + stringLatexEleve
            result = result + r"\newpage"
            
        result = result + "\n\n"
        result = result + r"\end{document}"
        
        return result

