import numpy as np


def stringForLatexForFloat(x):
    floatString = "{:.2f}".format(x)
    modele = r"\np{**NOMBRE**}"
    return modele.replace("**NOMBRE**", floatString)



class ResultatDS:
    
    def __init__(self, nom):
        self.nom = nom
        self.eleves = []
        self.parties = []
        self.resultats = []
        self.statistique = Statistique()
        self.statistiqueBrute = Statistique()
        self.dicoEleves = {}
        self.dicoQuestions = {}
        
    def eleveByName(self, nom):
        if nom in self.dicoEleves:
            return self.dicoEleves[nom]
        for x in self.eleves:
            if x.nom == nom:
                self.dicoEleves[nom] = x
                return x
        return None
        
    def questionByName(self, nom):
        if nom in self.dicoQuestions:
            return self.dicoQuestions[nom]
        for p in self.parties:
            for q in p.questions:
                if q.nom == nom:
                    self.dicoQuestions[nom] = q
                return q
        return None


class Statistique:
    
    def __init__(self):
        self.donnees = []
        self.moyenne = -1
        self.ecartType = -1
        self.max = -1
        self.min = -1

    def tailleEchantillon(self):
        return len(self.donnees)

    def ajouteDonnee(self, x):
        self.donnees.append(x)
        
    def moyenneListe(self, liste):
        N = len(liste)
        return sum(liste)/N
    
    def calculeIndicateurs(self):
        N = self.tailleEchantillon()
        if N >= 1:
            m = self.moyenneListe(self.donnees)
            ecarts = [(x-m)**2 for x in self.donnees]
            variance = self.moyenneListe(ecarts)
            ecartType = np.sqrt(variance)
            self.moyenne = m
            self.ecartType = ecartType
            self.max = max(self.donnees)
            self.min = min(self.donnees)

    def stringLatexForMoyenne(self):
        return stringForLatexForFloat(self.moyenne)

    def stringLatexForEcartType(self):
        return stringForLatexForFloat(self.ecartType)

class BilanDS:
    
    def __init__(self, eleve):
        self.eleve = eleve
        self.noteBrute = 0
        self.noteFinale = 0
        self.classement = -1
 
    def ajoutePoints(self, nbPoints):
        self.noteBrute = self.noteBrute + nbPoints
    
    def stringLatexForNoteFinale(self):
        return stringForLatexForFloat(self.noteFinale)


class Eleve:
    
    def __init__(self, nom, prenomEleve):
        self.nom = nom
        self.prenom = prenomEleve
        bilanDS = BilanDS(self)
        self.bilanDS = bilanDS

    def prenomEtNom(self):
        return self.prenom + " " + self.nom
        
    def stringForLatex(self):
        modele = r"**prenom** \textsc{**nom**}"
        result = modele.replace("**prenom**", self.prenom)
        result = result.replace("**nom**", self.nom)
        return result
      
      
class Question:
    
    def __init__(self, nom, coefficient, resolution):
        self.nom = nom
        self.coefficient = coefficient
        self.resolution = resolution
        self.partie = None
        self.statistique = Statistique()
        
class Partie:
    
    def __init__(self, nom):
        self.nom = nom
        self.questions = []
        self.uniquePartie = False
        self.statistique = Statistique()

        
    def ajouteQuestion(self, question):
        self.questions.append(question)
        question.partie = self


class ResultatQuestion:

    def __init__(self, eleve, question):
        self.eleve = eleve
        self.question = question
        self.valeur = 0
        self.estTraitee = False
        
    def attribueValeur(self, valeur):
        self.valeur = valeur
        self.estTraitee = True
        
    def nombreDePoints(self):
        return self.valeur/self.question.resolution*self.question.coefficient
      
        
##

# jacques = Eleve("DUPUIS", "Jacques")
# marie = Eleve("HÉZARD", "Marie")
# 
# qu1 = Question("Q1", 2, 4)
# qu2 = Question("Q2", 2, 4)
# qu3 = Question("Q3", 1, 1)
# 
# partie = Partie("Partie 1")