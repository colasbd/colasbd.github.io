#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May 12 10:34:37 2018

@author: colas
"""

from math import *

import math

def myCeil(x):
    if abs(x-int(x))<0.03 : return int(x)
    if abs(x-(int(x)+1))<0.03 : return int(x)+1
    if abs(x-(int(x)-1))<0.03 : return int(x)-1
    return math.ceil(x)


def myFloor(x):
    if abs(x-int(x))<0.03 : return int(x)
    if abs(x-(int(x)+1))<0.03 : return int(x)+1
    if abs(x-(int(x)-1))<0.03 : return int(x)-1
    return math.floor(x)


class LatexDiagramParameter:
    
    def __init__(self):
        self.numberOfBars = -1
        self.shouldDrawColoredBar = True
        self.withProtectionAgainstNegative = True
        self.width = ""
        self.height = ""
        self.withYAxis = True
        self.withFixedGlobalHeight = False


class LatexDiagramDrawer:

    def draw(self, listValues, selectedValue, parameter):
        numberOfBars = parameter.numberOfBars
        
        # Limit case
        if len(listValues) == 0:
            return ""
        
        # General case
        minValue = myFloor(min(listValues))
        maxValue = myCeil(max(listValues))
    
        stepGraph = (float(maxValue - minValue))/numberOfBars
        if stepGraph == 0:
            stepGraph = 1
        
        markedValues = [minValue + k*stepGraph for k in range(numberOfBars)]
        numberMarkedValues = [0 for k in range(numberOfBars)]
        for value in listValues :
            k = myCeil((value - minValue)/stepGraph) - 1
            k = max(k,0)
            numberMarkedValues[k] = numberMarkedValues[k] + 1
            
        coordinates = "{"
        for k in range(numberOfBars):
            coordinates = coordinates + "(" + str(markedValues[k]) + "," + str(numberMarkedValues[k]) + ")" + " (" + str(markedValues[k]+stepGraph) + "," + str(numberMarkedValues[k]) + ") \n"
    
        coordinates = coordinates + "};"
        
        strMaxYCoordinate = str(max(numberMarkedValues))
        strMaxYCoordinateBis = strMaxYCoordinate+".2"
            
        strFirstNextYTick = str(myCeil(max(numberMarkedValues)/5))
        
        result = ""
        
        if parameter.withFixedGlobalHeight:
            result += r"""\rule{0mm}{28mm}"""
        
        result += r"""\begin{tikzpicture}
    \begin{axis}[
        tick label style={font=\small},
        /pgf/number format/.cd,
        use comma,
        ymin=0, ymax=""" + strMaxYCoordinateBis + r""" ,
        ytick={0,""" + strFirstNextYTick + ",...," + strMaxYCoordinate + r"""},
        minor y tick num = 0,"""
        
        if parameter.withYAxis == False:
            result += r"""ytick style={draw=none},
        axis y line=none,"""
        
        result += r"""width=###width###,
        height=###height###,
        axis lines*=left,
        bar width=0.6cm,
        y axis line style = {draw = none},
        tick align      = outside,
        tick pos        = left
        ]\addplot+[ybar interval, mark=no, fill=black!20, draw=black!40] coordinates""" + coordinates
        
        if len(parameter.width) > 0:
            result = result.replace("###width###", parameter.width)
        else:
            result = result.replace("###width###", "10cm")
                                    
        if len(parameter.height) > 0:
            result = result.replace("###height###", parameter.height)
        else:
            result = result.replace("###height###", "5cm")
            
        shouldDrawColoredBar = parameter.shouldDrawColoredBar
        if parameter.withProtectionAgainstNegative:
            shouldDrawColoredBar = shouldDrawColoredBar and selectedValue >= 0
            
        if shouldDrawColoredBar:
            kSelectedValue = max(myCeil((selectedValue - minValue)/stepGraph) - 1,0)

            result = result + r"""
    \addplot+[ybar interval, mark=no, fill=black!70, draw=black!90] coordinates{""" + "(" + str(markedValues[kSelectedValue]) + "," + str(numberMarkedValues[kSelectedValue]) + ") " + " (" + str(markedValues[kSelectedValue]+stepGraph) + "," + str(numberMarkedValues[kSelectedValue]) + ") " + "};"
    
        result = result + r"""
    \end{axis}
    \end{tikzpicture}"""
    
        return result