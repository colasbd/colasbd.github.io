import os
os.chdir("/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/_TestReportMaker")

from ModelForTestReport import *
from DataExtractor import *
from LatexFileMaker import *



class TestReportMaker:
    
    def __init__(self, nomFichierCSV, nomDS):
        
        dataExtractor = DataExtractor(nomFichierCSV, nomDS)

        dataExtractor.extraitListeEleves()
        dataExtractor.creePartieEtQuestions()
        dataExtractor.extraitResultats()
        dataExtractor.calculeIndicateurs()
        
        self.resultatDS = dataExtractor.resultatDS
        
        self.latexFileMaker = LatexFileMaker()

    
    def createReport(self):
        
        nameFile = nomDS + "_rapport.tex"
        file = open(nameFile, "w", encoding = "utf-8")
        contentFile = self.latexFileMaker.stringLatexForDS(self.resultatDS)
        file.write(contentFile)
        file.close()


nomFichierCSV = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/DS1_exemple/tableau.csv"

nomDS = "DS_test"

testReportMaker = TestReportMaker(nomFichierCSV, nomDS)

##

testReportMaker.createReport()

