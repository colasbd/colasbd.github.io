import csv

class CSVReader:
    
    def __init__(self, delimiter):
        self.delimiter = delimiter
    
    # exemple: csvreader.processCSVFile(pathToFile, 4, 0, [1, 2, 3])
    # indexFirstLine est la ligne où commencent les données
    # indexLineKeys est la ligne où sont les clés (généralement 0)
    # indexesOtherOptions est la liste des lignes contenant les métadonnées
    # 
    def processCSVFile(self, pathToFile, indexFirstLine, indexLineKeys, indexesOtherOptions):
        csvfile = open(pathToFile, "r", encoding = 'utf-8-sig') 
        # avant je metteais : encoding = "utf-8"
        # cf. https://stackoverflow.com/a/49150749/1670830
        csvreader = csv.reader(csvfile, delimiter = self.delimiter)
        resultLines = []
        keys = []
        
        numberColumns = 0
        infosForKeys = {}
        
        indexLine = 0
        rows = []
        for row in csvreader:
            rows.append(row)
                                                         
        keys = rows[indexLineKeys]
        
        for key in keys:
            infosForKeys[key] = []
            
        for indexLine in indexesOtherOptions:
            row = rows[indexLine]
            for i in range(len(keys)):
                key = keys[i]
                infosForKeys[key].append(row[i])
        
        result = []
        nbRows = len(rows)
        for indexLine in range(indexFirstLine, nbRows):
            numberColumns = len(keys)
            dico = {}
            values = rows[indexLine]
            # la condition suivante permet d'exclure les lignes trop courtes
            if len(values) >= numberColumns:
                for k in range(numberColumns):
                    key = keys[k]
                    value = values[k]
                    dico[key] = value
            result.append(dico)
                
        return result, infosForKeys