pathToTestReportMaker = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/_TestReportMaker"

import os
os.chdir(pathToTestReportMaker)

from CSVReader import * 

##

monCSVReader = CSVReader(";")

##

pathToCSVFile = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/DS1_exemple/tableau.csv"

##

result, infosForKeys = monCSVReader.processCSVFile(pathToCSVFile, 3, 0, [1, 2])

