import os
from ModelForTestReport import *
from CSVReader import *

##


class DataExtractor:
    
    def __init__(self, nameFile):
        csvreader = CSVreader(??)
        data = csvreader.processCSVFile(??pathToFile, ??indexFirstLine, ??indexLineKeys, ??indexesOtherOptions)
        