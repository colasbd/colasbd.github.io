pathToTestReportMaker = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/_TestReportMaker"

import os
os.chdir(pathToTestReportMaker)

from ModelForTestReport import *
from CSVReader import *

##


class DataExtractor:
    
    def __init__(self, nameFile, nomDS):
        monCSVReader = CSVReader(";")
        result, infosForKeys = monCSVReader.processCSVFile(nameFile, 3, 0, [1, 2])
        self.result = result
        self.infosForKeys = infosForKeys
        self.resultatDS = ResultatDS(nomDS)
        
    def extraitListeEleves(self):
        for dico in self.result:
            nom = dico["NOM"]
            eleve = Eleve(nom, "")
            self.resultatDS.eleves.append(eleve)
            
    def creePartieEtQuestions(self):
        ??
        
    def extraitResultats(self):
        ??
            
            
##

pathToCSVFile = "/Users/colas/Dropbox/Maths/Maths_2023_2024/O. Formations/1. Création de rapports de correction/Rapports de DS/DS1_exemple/tableau.csv"

monDataExtractor = DataExtractor(pathToCSVFile, "DS Test")

##

monDataExtractor.extraitListeEleves()

def calculeIndicateur(qu):
    for resu in self.resultatDS.resultats()
    S = 0
    N = 0
    if resu.question == qu:
        if resu.estTraitee:
            S = resu.nombreDePoints()
            N = N+1
    qu.moyenneClass = S/N



