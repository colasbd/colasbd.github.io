class LaTeXFileMaker:
    
    def __init__(self):
        
        readPreambule = open("preambule.tex", "r", encoding = "utf-8")
        self.preambule = readPreambule.read()
        
        readGenericFile = open("genericFile.tex", "r", encoding = "utf-8")
        self.genericFile = readGenericFile.read()
        
        
    def ??fileForStudent
